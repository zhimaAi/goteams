const e="goteams:project-order-changed";export{e as P};
